﻿using System;

namespace OOP
{
    interface ICourseService
    {
        ICourseService()
        {

        }
        string[] Enrolled { get; }
    }
    interface IStudentService: IPersonService
    {

    }
    interface IInstructorService: IPersonService
    {

    }
    interface IDepartmentService
    {

    }
    interface IPersonService
    {
        IPersonService()
        {

        }
        int Age { get; set; }
        decimal Salary { get; set; }
        string Address { get; set; }

    }
    public class Person: IPersonService
    {
        public int Age { get; }
        public decimal Salary { get; }
        public string Address { get; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
