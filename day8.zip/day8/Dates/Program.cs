﻿using System;

namespace Dates
{
    class Program
    {
        static int WorkDays(string first, string last)
        {
            DateTime date1 = Convert.ToDateTime(first);
            DateTime date2 = Convert.ToDateTime(last);
            int count = 0;
            while (date1 <= date2)
            {
                if (date1.DayOfWeek != DayOfWeek.Saturday && date1.DayOfWeek != DayOfWeek.Sunday)
                {
                    count++;
                }
                date1 = date1.AddDays(1);
            }
            return count;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(WorkDays("05-03-2018","10-05-2018"));
        }
    }
}
