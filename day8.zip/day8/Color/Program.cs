﻿using System;

namespace Color
{
    class Color
    {
        int red;
        int green;
        int blue;
        int alpha;
        public Color(int r, int g, int b, int a = 255)
        {
            red = r;
            green = g;
            blue = b;
            alpha = a;
        }
        public int Red()
        {
            return red;
        }
        public int Green()
        {
            return green;
        }
        public int Blue()
        {
            return blue;
        }
        public int Alpha()
        {
            return alpha;
        }
        public int GrayScale()
        {
            return (this.red + this.green + this.blue) / 3;
        }

    }
    class Ball
    {
        int size;
        Color color;
        int thrown;
        public Ball(int s)
        {
            this.thrown = 0;
            this.size = s;

        }
        public void Pop()
        {
            this.size = 0;
        }
        public void Throw()
        {
            if (this.size != 0)
            {
                this.thrown += 1;
            }
        }
        public int Thrown()
        {
            return this.thrown;
        }


    }
    class Program
    {
        static void Main(string[] args)
        {
            Ball b1 = new Ball(1);
            Ball b2 = new Ball(2);
            b1.Throw();
            b1.Throw();
            b2.Throw();
            b2.Throw();
            b2.Pop();
            Console.WriteLine(b1.Thrown());
            Console.WriteLine(b2.Thrown());

        }
    }
}
