﻿using System;

namespace ReverseArray
{
    class Program
    {
        static int[] GenerateNumbers(int n)
        {
            int[] numbers = new int[n];
            Random rnd = new Random();
            for (int i = 0; i < n; i++)
            {
                numbers[i] = rnd.Next(9);
            }
            return numbers;
        }
        static void Reverse(int[] numbers)
        {
            for (int i = 0; i < numbers.Length/2; i++)
            {
                int j = numbers.Length - i - 1;
                int tmp = numbers[i];
                numbers[i] = numbers[j];
                numbers[j] = tmp;
            }
        }
        static void PrintNumbers(int[] numbers)
        {
            for (int i = 0; i < numbers.Length; i++)
            {
                Console.WriteLine(numbers[i]);
            }
        }
        static void Main(string[] args)
        {
            int[] numbers = GenerateNumbers(10);
            Reverse(numbers);
            PrintNumbers(numbers);
        }
    }
}
