﻿using System;
using System.Collections.Generic;
namespace Customer
{
    class Customer
    {
        string FirstName;
        string LastName;
        string Name 
        {
            get
            {
                return this.FirstName + " " + this.LastName;
            }
        }
        string Email;
        List<Order> orders;

        List<Order> Orders
        {
            get
            {
                return this.orders;
            }
        }

        public void AddOrder(Order od)
        {
            if (od == null)
            {
                return;
            }
            foreach( Order o in this.orders )
            {
                if (o.OrderNumber == od.OrderNumber)
                {
                    this.orders.Remove(o);
                }
            }
            this.orders.Add(od);
        }
    }
    class Order
    {
        private readonly Guid ordernumber;
        private DateTime orderdate;
        public Order()
        {
            this.ordernumber = Guid.NewGuid();
        }
        public Guid OrderNumber
        {
            get
            {
                return this.ordernumber;
            }
        }
        public DateTime OrderDate
        {
            get
            {
                return this.orderdate;
            }
            set
            {
                this.orderdate = value;
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Order o1 = new Order();
            o1.OrderDate = DateTime.Now;
            Customer c1 = new Customer();
        }
    }
}
