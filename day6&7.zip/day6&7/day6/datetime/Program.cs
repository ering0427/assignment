﻿using System;

namespace datetime
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime now = DateTime.Now;
            int hour = now.Hour;
            if (hour >= 3 && hour < 12)
            {
                Console.WriteLine("Good Morning.");
            }
            if (hour >= 12 && hour < 18)
            {
                Console.WriteLine("Good Afternoon.");
            }
            if (hour >= 18 && hour < 22)
            {
                Console.WriteLine("Good Evening.");
            }
            if (hour >= 22 || hour < 3)
            {
                Console.WriteLine("Good Night.");
            }
        }
    }
}
