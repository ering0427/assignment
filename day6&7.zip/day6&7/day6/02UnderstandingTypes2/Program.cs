﻿using System;

namespace _02UnderstandingTypes2
{
    class Program
    {
        static void Main(string[] args)
        {
            byte century;
            uint year;
            uint day;
            uint hour;
            ulong minute;
            ulong second;
            ulong milisecond;
            ulong microsecond;
            ulong nanosecond;

            Console.WriteLine("Please input an integer number of centuries: ");
            string val = Console.ReadLine();
            century = Convert.ToByte(val);
            year = Convert.ToUInt16(century * 100);
            day = year * 365;
            hour = day * 24;
            minute = hour * 60;
            second = minute * 60;
            milisecond = second * 1000;
            microsecond = milisecond * 1000;
            nanosecond = microsecond * 1000;

            Console.WriteLine($"{val} centuries = {year} years = {day} days = {hour} hours = {minute} minutes = {second} seconds = {milisecond} miliseconds = {microsecond} microseconds = {nanosecond} nanoseconds.");

        }
    }
}
