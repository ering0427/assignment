﻿using System;

namespace _02UnderstandingTypes
{
    class Program1
    {
        static void Main(string[] args)
        {
            string a = String.Format("The number of bytes for sbyte is {0}. The minimum value can be {1}. The maximum value can be {2}.", sizeof(sbyte), sbyte.MinValue, sbyte.MaxValue);
            string b = String.Format("The number of bytes for byte is {0}. The minimum value can be {1}. The maximum value can be {2}.", sizeof(byte), byte.MinValue, byte.MaxValue);
            string c = String.Format("The number of bytes for short is {0}. The minimum value can be {1}. The maximum value can be {2}.", sizeof(short), short.MinValue, short.MaxValue);
            string d = String.Format("The number of bytes for ushort is {0}. The minimum value can be {1}. The maximum value can be {2}.", sizeof(ushort), ushort.MinValue, ushort.MaxValue);
            string e = String.Format("The number of bytes for int is {0}. The minimum value can be {1}. The maximum value can be {2}.", sizeof(int), int.MinValue, int.MaxValue);
            string f = String.Format("The number of bytes for uint is {0}. The minimum value can be {1}. The maximum value can be {2}.", sizeof(uint), uint.MinValue, uint.MaxValue);
            string g = String.Format("The number of bytes for long is {0}. The minimum value can be {1}. The maximum value can be {2}.", sizeof(long), long.MinValue, long.MaxValue);
            string h = String.Format("The number of bytes for ulong is {0}. The minimum value can be {1}. The maximum value can be {2}.", sizeof(ulong), ulong.MinValue, ulong.MaxValue);
            string i = String.Format("The number of bytes for float is {0}. The minimum value can be {1}. The maximum value can be {2}.", sizeof(float), float.MinValue, float.MaxValue);
            string j = String.Format("The number of bytes for double is {0}. The minimum value can be {1}. The maximum value can be {2}.", sizeof(double), double.MinValue, double.MaxValue);
            string k = String.Format("The number of bytes for decimal is {0}. The minimum value can be {1}. The maximum value can be {2}.", sizeof(decimal), decimal.MinValue, decimal.MaxValue);
            Console.WriteLine(a);
            Console.WriteLine(b);
            Console.WriteLine(c);
            Console.WriteLine(d);
            Console.WriteLine(e);
            Console.WriteLine(f);
            Console.WriteLine(g);
            Console.WriteLine(h);
            Console.WriteLine(i);
            Console.WriteLine(j);
            Console.WriteLine(k);



        }
    }
}
