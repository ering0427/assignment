﻿using System;

namespace loops
{
    class Program
    {
        static void Main(string[] args)
        {
            int max = 500;

            for (byte i = 0; i < max; i++)
            {
                Console.WriteLine(i);
                if (i == 255)
                {
                    break;
                }
            }
        }
    }
}
