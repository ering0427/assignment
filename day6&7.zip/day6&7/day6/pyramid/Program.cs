﻿using System;

namespace pyramid
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i < 5; i++)
            {
                string s = "";
                for (int j = 0; j < 4 - i; j++)
                {
                    s += " ";
                }
                for (int j = 1; j <= i * 2 + 1; j++)
                {
                    s += "*";
                }
                for (int j = 0; j < 4 - i; j++)
                {
                    s += " ";
                }
                Console.WriteLine(s);
            }
        }
    }
}
