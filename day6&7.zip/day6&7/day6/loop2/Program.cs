﻿using System;

namespace loop2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please guess a number: ");
            int correctNumber = new Random().Next(3) + 1;
            int guessedNumber = int.Parse(Console.ReadLine());
            if (guessedNumber > correctNumber)
            {
                Console.WriteLine("Guessed high.");
            }
            else if (guessedNumber < correctNumber)
            {
                Console.WriteLine("Guessed low.");
            }
            else
            {
                Console.WriteLine("Answer is correct.");
            }
        }
    }
}
