﻿using System;

namespace countTo24
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 4; i++)
            {
                string count = "";
                for(int j = 0; j <= 24; j+=i)
                {
                    if (j != 0)
                    {
                        count += ",";
                        count += j.ToString();
                    }
                    else
                    {
                        count += j.ToString();
                    }

                }
                Console.WriteLine(count);
            }
        }
    }
}
