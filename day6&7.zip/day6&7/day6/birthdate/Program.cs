﻿using System;

namespace birthdate
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime today = DateTime.Today;
            Console.WriteLine("Please enter a birth date: ");
            DateTime birthday = DateTime.Parse(Console.ReadLine());
            double days = (today - birthday).TotalDays;
            double daysToNext = 10000 - (days % 10000);
            Console.WriteLine($"{days} days and {daysToNext} days to the next anniversary.");

        }
    }
}
