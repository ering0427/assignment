﻿using System;

namespace arrayCopy
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] array1 = new int[10] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
            int[] array2 = new int[array1.Length];

            for (int i = 0; i < array1.Length; i++)
            {
                array2[i] = array1[i];
            }
            foreach (int i in array1)
            {
                Console.WriteLine(i.ToString());
            }
            foreach (int i in array2)
            {
                Console.WriteLine(i.ToString());
            }
        }
    }
}
