﻿using System;
using System.Linq;

namespace MostFrequent
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = Console.ReadLine().Split().Select(int.Parse).ToArray();
            int max_freq = 1;
            int num = arr[0];
            for (int i = 0; i < arr.Length; i++)
            {
                int cur_freq = 1;
                for (int j = 0; j < arr.Length; j++)
                {
                    if (arr[j] == arr[i] && i != j)
                    {
                        cur_freq++;
                    }
                }
                if (cur_freq > max_freq)
                {
                    max_freq = cur_freq;
                    num = arr[i];
                }
            }
            Console.WriteLine(num.ToString());
        }
    }
}
