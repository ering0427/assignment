﻿using System;
using System.Collections.Generic;

namespace ToDoList
{
    class Program
    {
        static void Main(string[] args)
        {
            var list = new List<string>(); 
            for (; ; )
            {
                Console.WriteLine("Current contents of the list: ");
                for (int i = 0; i < list.Count; i ++)
                {
                    Console.WriteLine(list[i]);
                }
                Console.WriteLine("Enter command (+ item, - item, or -- to clear)");
                string input = Console.ReadLine();
                string[] items = input.Split(" ");
                if (items.Length == 1)
                {
                    list = new List<string>();
                }
                else if (items[0] == "+")
                {
                    list.Add(items[1]);
                }
                else if (items[0] == "-")
                {
                    list.Remove(items[1]);
                }
            }
        }
    }
}
