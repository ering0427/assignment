﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace palindrome
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = Console.ReadLine();
            string[] arr = s.Split(new char[] {',', ' ', '?', '!', ':', '.'});
            List<string> result = new List<string>();
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i].SequenceEqual(arr[i].Reverse()))
                {
                    result.Add(arr[i]);
                }
            }
            Console.WriteLine(String.Join(' ', result));
        }
    }
}
