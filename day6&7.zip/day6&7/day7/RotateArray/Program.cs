﻿using System;

namespace RotateArray
{
    class Program
    {
        static int mod(int x, int y)
        {
            int r = x % y;
            return r < 0 ? r + y : r;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Please input an array of n integers: ");
            string input = Console.ReadLine();
            string[] arr = input.Split(" ");
            Console.WriteLine("Please input the number of rotations k: ");
            int k = Int32.Parse(Console.ReadLine());

            int[] sum = new int[arr.Length];
            Array.Clear(sum, 0, sum.Length);
            for (int i = 1; i <= k; i++)
            {
                for (int j = 0; j < arr.Length; j++)
                {
                    sum[j] += Int32.Parse(arr[mod(j - i, arr.Length)]);
                }
            }
            for (int i = 0; i < sum.Length; i++)
            {
                Console.WriteLine(sum[i]);
            }

        }
    }
}
