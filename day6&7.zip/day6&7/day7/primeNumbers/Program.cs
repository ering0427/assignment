﻿using System;
using System.Collections.Generic;

namespace primeNumbers
{
    class Program
    {
        static int[] FindPrimesInRange(int startNum, int endNum)
        {
            List<int> primes = new List<int>();
            for (int i = startNum; i <= endNum; i++)
            {
                if (IsPrime(i))
                {
                    primes.Add(i);
                }
            }

            return primes.ToArray();
        }
        static bool IsPrime(int num)
        {
            if (num > 1)
            {
                for (int i = 2; i < num; i++)
                {
                    if (num % i == 0)
                    {
                        return false;
                    }
                }
            }
            return true;
        }
        static void Main(string[] args)
        {
            int[] primes = FindPrimesInRange(2, 10);
            for (int i = 0; i < primes.Length; i++)
            {
                Console.WriteLine(primes[i].ToString());
            }
        }
    }
}
