﻿using System;
using System.Linq;

namespace ReverseSentence
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = Console.ReadLine();
            char[] punc = {'.', ',', ':', ';', '=', '(', ')', '&', '[', ']', '"', '\'', '\\', '/', '!', '?', ' '};
            string[] arr = s.Split(' ');
            for (int i = 0; i < arr.Length; i++)
            {
                if (punc.Contains(arr[i][arr[i].Length - 1]) == false)
                {
                    char[] charArr = arr[i].ToCharArray();
                    Array.Reverse(charArr);
                    arr[i] = charArr.ToString();
                }
                else
                {
                    char c = arr[i][arr[i].Length - 1];
                    string tmp = arr[i].Remove(arr[i].Length - 1, 1);
                    char[] charArr = tmp.ToCharArray();
                    Array.Reverse(charArr);
                    arr[i] = charArr.ToString() + c;
                }
            }
            Console.WriteLine(String.Join(' ', arr));
        }
    }
}
