﻿using System;

namespace ReverseString
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = Console.ReadLine();
            string result = "";
            for (int i = s.Length - 1; i >= 0; i--)
            {
                result += s[i];
            }
            Console.WriteLine(result);

            char[] charArr = s.ToCharArray();
            Array.Reverse(charArr);
            Console.WriteLine(String.Join("", charArr));
        }
    }
}
