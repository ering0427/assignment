﻿using System;
using System.Linq;

namespace LongestSequence
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = Console.ReadLine().Split().Select(int.Parse).ToArray();

            int count = 1;
            int longest = 1;
            int num = arr[0];

            for (int i = 1; i < arr.Length; i++)
            {
                if (arr[i] != arr[i - 1])
                {
                    count = 0;
                }
                count++;

                if (count > longest)
                {
                    longest = count;
                    num = arr[i];
                }
            }
            string result = "";
            for (int i = 0; i < longest; i++)
            {
                result += num.ToString() + " ";
            }
            Console.WriteLine(result);
        }
    }
}
