﻿using System;

namespace URL
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = Console.ReadLine();
            string[] result = s.Split(new string[] {"://"}, StringSplitOptions.RemoveEmptyEntries);
            string protocol = result[0];
            string[] tmp = result[1].Split('/');
            string server = tmp[0];
            string resource = tmp[1];
        }
    }
}
